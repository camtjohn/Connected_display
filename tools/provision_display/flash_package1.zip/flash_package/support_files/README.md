# ESP32 Field Flash Package

This package contains everything needed to flash an ESP32-S3 device with pre-provisioned certificates.

## Contents
- `esptool.exe` - Flashing tool
- `flash.bat` - Automated flash script
- `bootloader.bin` - ESP32 bootloader
- `partition-table.bin` - Flash partition layout
- `nvs_certs.bin` - Pre-provisioned certificates and configuration
- `weather_display.bin` - Application firmware

## Requirements
- ESP32-S3 device connected via USB
- USB-to-Serial drivers installed (if needed)
- COM port number for your device

## Instructions

1. Connect the ESP32-S3 device to your computer via USB

2. Identify the COM port:
   - Open Device Manager
   - Look under "Ports (COM & LPT)"
   - Note the COM port number (e.g., COM3, COM18)

3. Run the flash script:
   ```
   flash.bat [COM_PORT]
   ```
   
   Examples:
   ```
   flash.bat 3
   flash.bat COM18
   ```

4. Wait for the flash process to complete (about 30 seconds)

5. The device will automatically restart with the new firmware

## Troubleshooting

**Error: COM port not found**
- Verify the device is connected
- Check Device Manager for the correct COM port
- Install USB-to-Serial drivers if needed

**Flash failed**
- Try a different USB cable
- Try a different USB port
- Reduce baud rate by editing flash.bat (change 460800 to 115200)

**Device doesn't boot after flash**
- Press the RESET button on the device
- Power cycle the device (unplug and replug USB)

## Device Information
- **Device Name**: Check configs.csv for device name (e.g., dev00, dev01)
- **Network SSID**: Connected_Display
- **Network Password**: setup1234
- **Zipcode**: Check configs.csv or NVS configuration

## Support
For issues or questions, contact technical support.
